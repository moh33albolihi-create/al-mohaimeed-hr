import { index, integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const employees = sqliteTable("employees", {
  id: integer("id").primaryKey({ autoIncrement: true }), code: text("code").notNull().unique(),
  name: text("name").notNull(), department: text("department").notNull(),
  branch: text("branch").notNull(), createdAt: text("created_at").notNull(),
});
export const leaveRequests = sqliteTable("leave_requests", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  type: text("type").notNull(), days: real("days").notNull(), startDate: text("start_date").notNull(),
  note: text("note").notNull().default(""), createdAt: text("created_at").notNull(),
}, (table) => [index("idx_leave_employee_date").on(table.employeeId, table.startDate)]);
export const permissions = sqliteTable("permissions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  minutes: integer("minutes").notNull(), permissionDate: text("permission_date").notNull(),
  note: text("note").notNull().default(""), createdAt: text("created_at").notNull(),
}, (table) => [index("idx_permission_employee_date").on(table.employeeId, table.permissionDate)]);
