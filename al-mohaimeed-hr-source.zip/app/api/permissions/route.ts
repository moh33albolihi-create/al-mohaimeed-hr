import { and, eq, gte, lt, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { permissions } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json() as { employeeId?: number; minutes?: number; permissionDate?: string; note?: string };
    if (!body.employeeId || !body.minutes || body.minutes <= 0 || !body.permissionDate) return Response.json({ error: "بيانات الاستئذان غير مكتملة" }, { status: 400 });
    const d = new Date(`${body.permissionDate}T00:00:00Z`); const y = d.getUTCFullYear(); const m = d.getUTCMonth();
    const start = `${y}-${String(m + 1).padStart(2, "0")}-01`; const end = new Date(Date.UTC(y, m + 1, 1)).toISOString().slice(0, 10); const db = getDb();
    const [total] = await db.select({ used: sql<number>`coalesce(sum(${permissions.minutes}), 0)` }).from(permissions)
      .where(and(eq(permissions.employeeId, body.employeeId), gte(permissions.permissionDate, start), lt(permissions.permissionDate, end)));
    if (Number(total.used) + body.minutes > 240) return Response.json({ error: `الرصيد غير كافٍ. المتبقي ${Math.max(0, 240 - Number(total.used))} دقيقة` }, { status: 400 });
    await db.insert(permissions).values({ employeeId: body.employeeId, minutes: Math.round(body.minutes), permissionDate: body.permissionDate, note: body.note?.trim() || "", createdAt: new Date().toISOString() });
    return Response.json({ ok: true }, { status: 201 });
  } catch { return Response.json({ error: "تعذر تسجيل الاستئذان" }, { status: 500 }); }
}
