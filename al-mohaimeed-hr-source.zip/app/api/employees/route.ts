import { and, eq, gte, lt, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { employees, leaveRequests, permissions } from "@/db/schema";

export async function GET() {
  try {
    const db = getDb();
    const now = new Date();
    const yearStart = `${now.getUTCFullYear()}-01-01`;
    const yearEnd = `${now.getUTCFullYear() + 1}-01-01`;
    const monthStart = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-01`;
    const monthEndDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
    const monthEnd = monthEndDate.toISOString().slice(0, 10);
    const rows = await db.select().from(employees).orderBy(employees.name);
    const result = await Promise.all(rows.map(async (employee) => {
      const [leave] = await db.select({ used: sql<number>`coalesce(sum(${leaveRequests.days}), 0)` }).from(leaveRequests)
        .where(and(eq(leaveRequests.employeeId, employee.id), gte(leaveRequests.startDate, yearStart), lt(leaveRequests.startDate, yearEnd)));
      const [permission] = await db.select({ used: sql<number>`coalesce(sum(${permissions.minutes}), 0)` }).from(permissions)
        .where(and(eq(permissions.employeeId, employee.id), gte(permissions.permissionDate, monthStart), lt(permissions.permissionDate, monthEnd)));
      return { ...employee, leaveUsed: Number(leave.used), leaveRemaining: Math.max(0, 21 - Number(leave.used)), permissionUsed: Number(permission.used), permissionRemaining: Math.max(0, 240 - Number(permission.used)) };
    }));
    return Response.json({ employees: result });
  } catch { return Response.json({ error: "تعذر تحميل بيانات الموظفين" }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as { code?: string; name?: string; department?: string; branch?: string };
    const code = body.code?.trim(); const name = body.name?.trim();
    if (!code || !name || !body.department || !body.branch) return Response.json({ error: "أكمل جميع بيانات الموظف" }, { status: 400 });
    const db = getDb();
    const [employee] = await db.insert(employees).values({ code, name, department: body.department, branch: body.branch, createdAt: new Date().toISOString() }).returning();
    return Response.json({ employee }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("UNIQUE") ? "كود الموظف مستخدم مسبقًا" : "تعذر إضافة الموظف";
    return Response.json({ error: message }, { status: 400 });
  }
}
