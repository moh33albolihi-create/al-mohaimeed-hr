import { and, eq, gte, lt, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { leaveRequests } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json() as { employeeId?: number; type?: string; days?: number; startDate?: string; note?: string };
    if (!body.employeeId || !["عادية", "طارئة"].includes(body.type || "") || !body.days || body.days <= 0 || !body.startDate) return Response.json({ error: "بيانات الإجازة غير مكتملة" }, { status: 400 });
    const year = Number(body.startDate.slice(0, 4)); const db = getDb();
    const [total] = await db.select({ used: sql<number>`coalesce(sum(${leaveRequests.days}), 0)` }).from(leaveRequests)
      .where(and(eq(leaveRequests.employeeId, body.employeeId), gte(leaveRequests.startDate, `${year}-01-01`), lt(leaveRequests.startDate, `${year + 1}-01-01`)));
    if (Number(total.used) + body.days > 21) return Response.json({ error: `الرصيد غير كافٍ. المتبقي ${21 - Number(total.used)} يوم` }, { status: 400 });
    await db.insert(leaveRequests).values({ employeeId: body.employeeId, type: body.type!, days: body.days, startDate: body.startDate, note: body.note?.trim() || "", createdAt: new Date().toISOString() });
    return Response.json({ ok: true }, { status: 201 });
  } catch { return Response.json({ error: "تعذر تسجيل الإجازة" }, { status: 500 }); }
}
