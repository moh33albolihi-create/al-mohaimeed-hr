"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Building2, CalendarDays, Clock3, Plus, RefreshCw, UsersRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

type Employee = { id:number; code:string; name:string; department:string; branch:string; leaveUsed:number; leaveRemaining:number; permissionUsed:number; permissionRemaining:number };
const departments = ["الإدارة العليا", "المالية", "الموارد البشرية", "الحركة والتشغيل", "المستودع والمخازن", "إدارة المشتريات"];
const branches = ["الرئيسي", "حرض", "ستون بور"];
const today = new Date().toISOString().slice(0, 10);

function Field({ label, children }: { label:string; children:React.ReactNode }) { return <label className="field"><span>{label}</span>{children}</label>; }
function hours(minutes:number) { const h=Math.floor(minutes/60), m=minutes%60; return m ? `${h} س و${m} د` : `${h} ساعات`; }

export default function Home() {
  const [employees,setEmployees]=useState<Employee[]>([]); const [loading,setLoading]=useState(true); const [notice,setNotice]=useState("");
  const load=useCallback(async()=>{ setLoading(true); try { const r=await fetch("/api/employees"); const j=await r.json(); if(!r.ok) throw new Error(j.error); setEmployees(j.employees); } catch(e){ setNotice(e instanceof Error?e.message:"حدث خطأ"); } finally{setLoading(false);} },[]);
  useEffect(()=>{void load();},[load]);
  useEffect(()=>{
    const context=(document as Document & {modelContext?:{registerTool:(tool:unknown, options?:{signal?:AbortSignal})=>void|Promise<void>}}).modelContext;
    if(!context?.registerTool) return;
    const lifecycle=new AbortController();
    const post=async(endpoint:string,input:unknown)=>{const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(input)});const j=await r.json();if(!r.ok) throw new Error(j.error||"تعذر الحفظ");await load();return j;};
    const tools=[
      {name:"add_employee",title:"إضافة موظف",description:"إضافة موظف جديد إلى نظام مجموعة المحيميد القابضة.",inputSchema:{type:"object",properties:{code:{type:"string"},name:{type:"string"},department:{type:"string",enum:departments},branch:{type:"string",enum:branches}},required:["code","name","department","branch"],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:(input:unknown)=>post("/api/employees",input)},
      {name:"record_leave",title:"تسجيل إجازة",description:"تسجيل إجازة عادية أو طارئة وخصمها من رصيد الموظف السنوي.",inputSchema:{type:"object",properties:{employeeId:{type:"number"},type:{type:"string",enum:["عادية","طارئة"]},days:{type:"number",minimum:.5},startDate:{type:"string"},note:{type:"string"}},required:["employeeId","type","days","startDate"],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:(input:unknown)=>post("/api/leaves",input)},
      {name:"record_permission",title:"تسجيل استئذان",description:"تسجيل مدة استئذان بالدقائق وخصمها من رصيد الموظف الشهري.",inputSchema:{type:"object",properties:{employeeId:{type:"number"},minutes:{type:"number",minimum:1},permissionDate:{type:"string"},note:{type:"string"}},required:["employeeId","minutes","permissionDate"],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:(input:unknown)=>post("/api/permissions",input)}
    ];
    tools.forEach(tool=>{try{void Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}});
    return()=>lifecycle.abort();
  },[load]);
  const totals=useMemo(()=>({ leave:employees.reduce((n,e)=>n+e.leaveUsed,0), permission:employees.reduce((n,e)=>n+e.permissionUsed,0) }),[employees]);
  async function submit(endpoint:string, data:Record<string,unknown>, form:HTMLFormElement){ setNotice(""); const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)}); const j=await r.json(); if(!r.ok){setNotice(j.error||"تعذر حفظ البيانات");return;} form.reset(); setNotice("تم الحفظ بنجاح"); await load(); }

  return <main className="min-h-screen bg-[#f3f6f4] text-[#14231f]">
    <header className="topbar"><div className="brand-mark">م</div><div><p>مجموعة المحيميد القابضة</p><span>نظام إدارة الموظفين</span></div><div className="header-date">{new Intl.DateTimeFormat("ar-SA",{dateStyle:"long"}).format(new Date())}</div></header>
    <div className="workspace">
      <section className="welcome"><div><span className="eyebrow">لوحة الموارد البشرية</span><h1>الموظفون والأرصدة</h1><p>إدارة الإجازات السنوية والاستئذانات الشهرية من مكان واحد.</p></div><Button onClick={()=>void load()} variant="outline"><RefreshCw/> تحديث</Button></section>
      {notice&&<div className={notice.includes("بنجاح")?"notice success":"notice"}>{notice}</div>}
      <section className="stats">
        <article><div className="stat-icon"><UsersRound/></div><div><span>إجمالي الموظفين</span><strong>{employees.length}</strong></div></article>
        <article><div className="stat-icon gold"><CalendarDays/></div><div><span>أيام الإجازات المستخدمة</span><strong>{totals.leave}</strong></div></article>
        <article><div className="stat-icon blue"><Clock3/></div><div><span>ساعات الاستئذان هذا الشهر</span><strong>{hours(totals.permission)}</strong></div></article>
      </section>

      <Tabs defaultValue="employees" className="panel">
        <TabsList className="tabs" variant="line"><TabsTrigger value="employees"><UsersRound/>الموظفون</TabsTrigger><TabsTrigger value="leaves"><CalendarDays/>الإجازات</TabsTrigger><TabsTrigger value="permissions"><Clock3/>الاستئذان</TabsTrigger></TabsList>
        <TabsContent value="employees" className="content-grid">
          <section className="form-card"><div className="section-title"><Plus/><div><h2>إضافة موظف</h2><p>يبدأ الموظف برصيد 21 يوم إجازة و4 ساعات استئذان شهريًا.</p></div></div>
            <form onSubmit={e=>{e.preventDefault();const f=e.currentTarget;const d=new FormData(f);void submit("/api/employees",Object.fromEntries(d),f)}}>
              <Field label="كود الموظف"><Input name="code" required placeholder="مثال: EMP-001"/></Field><Field label="اسم الموظف"><Input name="name" required placeholder="الاسم الكامل"/></Field>
              <Field label="الإدارة"><NativeSelect name="department" required className="w-full"><NativeSelectOption value="">اختر الإدارة</NativeSelectOption>{departments.map(x=><NativeSelectOption key={x}>{x}</NativeSelectOption>)}</NativeSelect></Field>
              <Field label="الفرع"><NativeSelect name="branch" required className="w-full"><NativeSelectOption value="">اختر الفرع</NativeSelectOption>{branches.map(x=><NativeSelectOption key={x}>{x}</NativeSelectOption>)}</NativeSelect></Field>
              <Button type="submit" className="submit"><Plus/>إضافة الموظف</Button>
            </form>
          </section>
          <EmployeeTable employees={employees} loading={loading}/>
        </TabsContent>
        <TabsContent value="leaves" className="content-grid">
          <section className="form-card"><div className="section-title"><CalendarDays/><div><h2>تسجيل إجازة</h2><p>يُخصم عدد الأيام مباشرة من رصيد الموظف السنوي.</p></div></div>
            <form onSubmit={e=>{e.preventDefault();const f=e.currentTarget,d=new FormData(f);void submit("/api/leaves",{employeeId:Number(d.get("employeeId")),type:d.get("type"),days:Number(d.get("days")),startDate:d.get("startDate"),note:d.get("note")},f)}}>
              <EmployeePicker employees={employees}/><Field label="نوع الإجازة"><NativeSelect name="type" required className="w-full"><NativeSelectOption value="عادية">إجازة عادية</NativeSelectOption><NativeSelectOption value="طارئة">إجازة طارئة</NativeSelectOption></NativeSelect></Field>
              <Field label="عدد الأيام"><Input name="days" type="number" min="0.5" max="21" step="0.5" required/></Field><Field label="تاريخ البداية"><Input name="startDate" type="date" defaultValue={today} required/></Field><Field label="ملاحظة (اختياري)"><Input name="note" placeholder="سبب أو ملاحظة"/></Field>
              <Button type="submit" className="submit">تسجيل الإجازة</Button>
            </form>
          </section><BalanceCards employees={employees} type="leave"/>
        </TabsContent>
        <TabsContent value="permissions" className="content-grid">
          <section className="form-card"><div className="section-title"><Clock3/><div><h2>تسجيل استئذان</h2><p>الحد الشهري 4 ساعات لكل موظف ويتجدد تلقائيًا.</p></div></div>
            <form onSubmit={e=>{e.preventDefault();const f=e.currentTarget,d=new FormData(f);const mins=Number(d.get("hours"))*60+Number(d.get("minutes"));void submit("/api/permissions",{employeeId:Number(d.get("employeeId")),minutes:mins,permissionDate:d.get("permissionDate"),note:d.get("note")},f)}}>
              <EmployeePicker employees={employees}/><div className="split"><Field label="الساعات"><Input name="hours" type="number" min="0" max="4" defaultValue="1" required/></Field><Field label="الدقائق"><Input name="minutes" type="number" min="0" max="59" defaultValue="0" required/></Field></div>
              <Field label="التاريخ"><Input name="permissionDate" type="date" defaultValue={today} required/></Field><Field label="ملاحظة (اختياري)"><Input name="note" placeholder="سبب الاستئذان"/></Field><Button type="submit" className="submit">تسجيل الاستئذان</Button>
            </form>
          </section><BalanceCards employees={employees} type="permission"/>
        </TabsContent>
      </Tabs>
      <footer><Building2/> مجموعة المحيميد القابضة</footer>
    </div>
  </main>;
}

function EmployeePicker({employees}:{employees:Employee[]}){return <Field label="الموظف"><NativeSelect name="employeeId" required className="w-full"><NativeSelectOption value="">اختر الموظف</NativeSelectOption>{employees.map(e=><NativeSelectOption key={e.id} value={e.id}>{e.name} — {e.code}</NativeSelectOption>)}</NativeSelect></Field>}
function EmployeeTable({employees,loading}:{employees:Employee[];loading:boolean}){return <section className="data-card"><div className="section-heading"><div><h2>قائمة الموظفين</h2><p>{employees.length} موظف مسجل</p></div></div>{loading?<div className="empty">جاري تحميل البيانات…</div>:employees.length===0?<div className="empty"><UsersRound/><b>لا يوجد موظفون بعد</b><span>أضف أول موظف من النموذج.</span></div>:<Table><TableHeader><TableRow><TableHead>الموظف</TableHead><TableHead>الإدارة</TableHead><TableHead>الفرع</TableHead><TableHead>الإجازة</TableHead><TableHead>الاستئذان</TableHead></TableRow></TableHeader><TableBody>{employees.map(e=><TableRow key={e.id}><TableCell><b>{e.name}</b><small>{e.code}</small></TableCell><TableCell>{e.department}</TableCell><TableCell>{e.branch}</TableCell><TableCell><b>{e.leaveRemaining}</b> / 21 يوم</TableCell><TableCell><b>{hours(e.permissionRemaining)}</b> متبقي</TableCell></TableRow>)}</TableBody></Table>}</section>}
function BalanceCards({employees,type}:{employees:Employee[];type:"leave"|"permission"}){return <section className="data-card"><div className="section-heading"><div><h2>{type==="leave"?"أرصدة الإجازات":"رصيد الاستئذان الشهري"}</h2><p>{type==="leave"?"يتجدد سنويًا":"يتجدد مع بداية كل شهر"}</p></div></div><div className="balances">{employees.length===0?<div className="empty">أضف موظفًا لعرض الأرصدة</div>:employees.map(e=>{const used=type==="leave"?e.leaveUsed:e.permissionUsed, max=type==="leave"?21:240, remain=type==="leave"?e.leaveRemaining:e.permissionRemaining;return <article key={e.id}><div className="balance-head"><div><b>{e.name}</b><span>{e.code} · {e.branch}</span></div><strong>{type==="leave"?`${remain} يوم`:hours(remain)}</strong></div><Progress value={Math.min(100,(used/max)*100)}/><div className="balance-meta"><span>المستخدم: {type==="leave"?`${used} يوم`:hours(used)}</span><span>المتبقي من {type==="leave"?"21 يوم":"4 ساعات"}</span></div></article>})}</div></section>}
